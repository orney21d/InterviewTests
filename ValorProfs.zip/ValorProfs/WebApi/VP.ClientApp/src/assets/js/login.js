let loginComponent = {
    template: `
    <div class="col-md-6 offset-3">
    <h3>Login</h3>
    <div v-if="error" class="text-danger">{{ error }}</div>
    <form novalidate @submit.prevent="onSubmit">
      <div class="form-group">
        <label for="Email">Email</label>
        <input type="text" 
               name="Email" 
               class="form-control" 
               v-model="credentials.Email" />
      </div>
      <div class="form-group">
        <label for="Pass">Password</label>
        <input type="password" 
               name="Pass" 
               class="form-control" 
               v-model="credentials.Pass" />
      </div>
      <div class="form-group">
        <input type="submit" class="btn btn-success" value="Login" />
      </div>
    </form>
  </div>
`,
    data: function() {
        return {
            credentials: {},
            error: ""
        }
    },
    methods: {
        onSubmit: function() {
            this.$store.dispatch("doAuth", this.credentials)
                .then(
                    function(result) {
                        this.$router.push("/");

                    }
                )
                .catch(function(ex) {
                    this.error = "Failed to login"
                });

        }
    }

};

//Defining Component that is used in the route
let Login = Vue.component("login", loginComponent);