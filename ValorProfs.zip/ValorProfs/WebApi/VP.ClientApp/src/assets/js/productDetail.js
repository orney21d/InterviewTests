let productDetailComponent = {

    data: function() {
        return {
            //For the management of specific product
            product: {},
            isBusy: false,
            error: ""
        }
    },
    props: {

        id: {
            type: String
        },
        //Allow passing value that set the product to edit...
        currentProduct: {
            required: false
        },
        isEditMode: {
            required: false,
            type: Boolean
        }

    },

    mounted: function() {
        this.isBusy = true;
        this.isEditMode = false;
        if (this.currentProduct) {
            this.product = this.currentProduct;
            this.isEditMode = true;
        } else {
            this.$store.dispatch("findProduct", this.id) //return a  Promise
                .then(function(res) {
                    this.product = res;
                    this.isBusy = false;
                }.bind(this))
                .catch(function() {
                    this.error = "Could not load products...";
                    this.isBusy = false;
                }.bind(this))
        }

    }

};


let ProductDetail = Vue.component("product-detail", function(resolve, reject) {
    axios.get("/templates/productDetail.html"). //Getting the Html code
    then(function(res) {

            productDetailComponent.template = res.data;
            resolve(productDetailComponent);

        })
        .catch(function() { reject(); }); //rejecting in case of error
});