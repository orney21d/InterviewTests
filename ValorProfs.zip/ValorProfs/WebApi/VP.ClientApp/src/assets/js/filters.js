/**
 * 
 *Defining global Filter
 */
Vue.filter("date", function(val) {
    return val.toDateString();
});

/**
 * 
 *Definiendo el filtro global
 */
Vue.filter("money", function(val, decimalPlaces, symbol) {
    if (decimalPlaces === undefined)
        decimalPlaces = 2;
    if (symbol === undefined)
        symbol = "$";
    return symbol + val.toFixed(decimalPlaces);
});