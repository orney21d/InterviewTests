// store.js
//Using Vuex to maintain state Data. For the states, I manage "products", "token"(for the auth) and "isAdmin"
let store = new Vuex.Store({
    state: {
        //Product list
        products: [],
        token: "",
        isAdmin: false
    },
    mutations: {

        //Set products List
        setProducts: function(state, newProductList) {
            state.products = newProductList;
        },
        //Add Product to List
        addProductToList: function(state, product) {
            state.products.push(product);
        },
        //Clear product list
        clearProductList: function(state) {
            state.products = [];
        },
        deleteProduct: function(state, product) {
            let index = _.findIndex(state.products, {
                Id: product.Id
            });
            state.products.splice(index, 1);
        },
        //Set auth token
        setToken(state, tokenInfo) {
            state.token = tokenInfo.token;
            state.isAdmin = (tokenInfo.role == "Admin");
        }
    },

    actions: {
        //Load the existents products
        loadProducts: function(context) {
            return new Promise(function(resolve, reject) {
                axios.get("http://localhost:5000/api/products", { headers: { 'crossDomain': true } })
                    .then(function(res) {
                        context.commit("setProducts", res.data.results);
                        resolve();
                    })
                    .catch(function() {
                        reject();
                    });
            });
        },
        //Made Authentication process
        doAuth(context, creds) {
            return new Promise(function(resolve, reject) {
                axios.post("http://oems.ddns.net/api/token/", creds, { headers: { 'crossDomain': true } })
                    .then((res) => {
                        context.commit("setToken", res.data); // Auth success
                        resolve();
                    })
                    .catch(function(ex) {
                        reject();
                    });
            });
        },
        deleteProduct: function(context, product) {
            return new Promise(function(resolve, reject) {
                axios.delete("http://localhost:5000/api/products", product.Id, { headers: { 'crossDomain': true } })
                    .then(function(res) {
                        context.commit("deleteProduct", product);
                        resolve();
                    })
                    .catch(function() {
                        reject();
                    });
            });
        },

        //Search a Product
        findProduct: function(context, id) {

            return new Promise(function(resolve, reject) {
                if (context.state.products.length == 0) {
                    //load catalog
                    context.dispatch("loadProducts")
                        .then(function() {
                            resolve(_.find(context.state.products, { Id: id }));
                        })
                        .catch(function() {
                            reject();
                        })
                } else {
                    resolve(_.find(context.state.products, { Id: id }));
                }
            });



        }
    },
    getters: {
        isAuthenticated: function(state) {
            return state.token;
        },

        isAdmin: function(state) {
            return state.isAdmin;
        },


    }
});