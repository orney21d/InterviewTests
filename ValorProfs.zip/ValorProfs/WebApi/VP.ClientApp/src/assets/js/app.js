Vue.use(VueRouter); //Adding Vue Routing

//Defining App routes
let routes = [{

        path: "/",
        component: ProductList,
        meta: {
            authRequired: true
        }
    },
    {

        path: "/product:id",
        component: ProductDetail,
        name: "productDetail",
        props: true,
        meta: {
            authRequired: true
        }
    },
    {

        path: "/login",
        component: Login
    }
];

let theRouter = new VueRouter({ routes });

//Check if the path require Authentication. If the user is not authenticated redirect to page
theRouter.beforeEach(function(to, _from, next) {
    if (to.meta.authRequired) {
        if (store.getters.isAuthenticated == false) {
            next({ path: "/login" });
            return; // Prevent the main next() from being called
        }
    }
    next();
});

new Vue({
    el: "#App",
    store,
    router: theRouter
});