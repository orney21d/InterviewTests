//productList Component
var productListComponent = {
    data: function() {

        return {
            appName: "Product List",
            error: ""

        }
    },

    methods: {
        onDelete: function(product) {
            if (!this.$store.getters.isAdmin) {
                this.error = "Acess denied."
                return;
            }
            this.$store.dispatch("deleteProduct", product)
                .then(
                    function(result) {
                        this.$router.push("/");
                    }
                )
                .catch(function() {
                    this.error = "Unable to delete product"
                });

        },



    },

    mounted: function() {
        this.error = "";
        this.$store.dispatch("loadProducts")
            .catch(function() { this.error = "Could not load products." });
    },

};

let ProductList = Vue.component("product-list", function(resolve, reject) {
    axios.get("/templates/productList.html"). //Getting the Html code
    then(function(res) {

            productListComponent.template = res.data;
            resolve(productListComponent);

        })
        .catch(function() { reject(); }); //rejecting in case of error
});