﻿using System;

namespace VP.Dal
{
    public class Class1
    {
    }
}
