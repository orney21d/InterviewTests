﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VP.Api.Infrastructure.HttpErrors;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// Extension Methods to add over IServiceCollection
    /// </summary>
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddCustomServices(this IServiceCollection services)
        {
            services
                .AddSingleton<IHttpErrorFactory, DefaultHttpErrorFactory>();

            return services;
        }

        /// <summary>
        /// Configure JWT Authentication. This process is inherent to Host
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public static IServiceCollection AddJWTAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddAuthentication(cfg =>
            {
                cfg.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme; // Definiendo el esquema por defecto JWT, para evitar que tome el de "Cookie Auth" que es el de por defecto...
                cfg.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;    // Definiendo el esquema por defecto JWT, para evitar que tome el de "Cookie Auth" que es el de por defecto...
                

            })
               .AddJwtBearer(options =>
               {
                   //options.RequireHttpsMetadata = false;
                   options.TokenValidationParameters = new TokenValidationParameters
                   {
                       ValidateIssuer = false, // This should be true, but for PoC
                       ValidateAudience = false, // This should be true, but for PoC
                       ValidateLifetime = true,
                       ValidateIssuerSigningKey = true,
                       
                       ValidIssuer = configuration["Jwt:Issuer"], //The string params configuration can be typed with IOptions for example... But for PoC...
                       ValidAudience = configuration["Jwt:Issuer"],//The string params configuration can be typed with IOptions for example... But for PoC...
                       IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]))//The string params configuration can be typed with IOptions for example... But for PoC...
                      
                   };
                   
               });

            return services;
        }

        /// <summary>
        /// Configure Cors configuration
        /// </summary>
        /// <param name="services"></param>
        /// <param name="corsPolicy"></param>
        /// <returns></returns>
        public static IServiceCollection AddCorsConfig(this IServiceCollection services, string corsPolicy)
        {

             services.AddCors(options =>
              {
                  options.AddPolicy(corsPolicy,
                      builder =>
                          //This values should be at DDBB or some Config file.
                          builder.WithOrigins(new string[] { "https://plnkr.co/", "https://www.plnkr.co/"
                            ,"http://plnkr.co/"
                            ,"http://www.plnkr.co/"

                          }) //
                          .AllowAnyMethod()
                          .AllowAnyHeader()
                          .AllowCredentials()
                  .Build());
              });

            return services;
        }
    }
}
