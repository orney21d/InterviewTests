﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using VP.Api;

namespace VP.Host
{
    public class Startup
    {
        #region Fields
        private readonly string corsPolicy = "CorsPolicy";
        #endregion

        #region Constructors
        public Startup(IConfiguration configuration, IHostingEnvironment env)
        {
            Configuration = configuration;
            Env = env;
        }
        #endregion

        #region Properties
        public IConfiguration Configuration { get; }

        public IHostingEnvironment Env { get; }
        #endregion

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddJWTAuthentication(Configuration);
            //Configuring JWT Auth before passsing services to WebApi Configuration Services
            ConfigurationApi.ConfigureServices(services, Configuration, Env)
               .AddCustomServices()
               .AddCorsConfig(corsPolicy); //Config Cors to allow access from diferents domains. I'm not validating issuer cause PoC
            //.AddOpenApi();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseAuthentication();
            ConfigurationApi.Configure(
                app,
                host => host
                .UseIf(env.IsDevelopment(), appBuilder => appBuilder.UseDeveloperExceptionPage())
                
            );
        }


    }
}
