﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP.Host.Loggers
{
    /// <summary>
    /// Class used to mark Logger category
    /// </summary>
    public abstract class VPTestLogCategory
    {
        
    }
}
