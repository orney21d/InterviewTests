﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VP.Api.Infrastructure.HttpErrors;
using VP.Host.Loggers;

namespace VP.Host.Middleware
{
    /// <summary>
    /// Middleware to intercept errors and centralize theirs in  an object through IHttpErrorFactory
    /// </summary>
    public class ErrorHandlerMiddleware
    {
        private readonly RequestDelegate next;
        private readonly IHttpErrorFactory httpErrorFactory;
        private readonly ILogger<VPTestLogCategory> logger;
        

        public ErrorHandlerMiddleware(
            RequestDelegate next,
            IHttpErrorFactory httpErrorFactory,
            ILogger<VPTestLogCategory> logger)
        {
            this.next = next ?? throw new ArgumentNullException(nameof(next));
            this.httpErrorFactory = httpErrorFactory ?? throw new ArgumentNullException(nameof(httpErrorFactory));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await next(context);
            }
            catch (Exception exception)
            {
                logger.LogError(exception.HResult, exception, exception.Message);
                await CreateHttpError(context, exception);
            }
        }

        private async Task CreateHttpError(HttpContext context, Exception exception)
        {
            HttpError error = httpErrorFactory.CreateFrom(exception);

            await WriteResponseAsync(
                context,
                JsonConvert.SerializeObject(error),
                "application/json",
                error.Status);
        }

        private Task WriteResponseAsync(
           HttpContext context,
           string content,
           string contentType,
           int statusCode)
        {
            context.Response.Headers["Content-Type"] = new[] { contentType };
            context.Response.Headers["Cache-Control"] = new[] { "no-cache, no-store, must-revalidate" };
            context.Response.Headers["Pragma"] = new[] { "no-cache" };
            context.Response.Headers["Expires"] = new[] { "0" };
            context.Response.StatusCode = statusCode;

            return context.Response.WriteAsync(content);
        }
    }
}
