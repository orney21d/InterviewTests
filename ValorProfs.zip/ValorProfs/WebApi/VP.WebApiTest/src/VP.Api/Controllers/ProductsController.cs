﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using VP.Api.Base;
using VP.Api.Core;
using VP.Api.Infrastructure.HttpErrors;
using VP.Api.Models;

namespace VP.Api.Controllers
{

    /// <summary>
    /// Manage the products operations
    /// </summary>
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)] //Specifying the Bearer scheme cause after 2.0 "Authorize" always try to redirect to loging page returning as result 404 in bearer auth...
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController: VPControllerBase
    {

        private readonly UserManager<IdentityUser> _userManager;

        private readonly RoleManager<IdentityRole> _roleManager;

        private readonly IProductRepository _productRepository;

        public ProductsController(UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager, IProductRepository productRepository)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _productRepository = productRepository;
        }

        // GET api/products

        /// <summary>
        /// Get All products
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Authorize(Roles = nameof(VPRoles.Admin)+ "," + nameof(VPRoles.User))]
        [SwaggerResponse(StatusCodes.Status200OK, typeof(IEnumerable<Product>))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError, typeof(HttpError))]
        public async Task<IEnumerable<Product>> Get()
        {
            //By the fact I'm generating the Auth token with a private key, I'm assuming the user have access
            //If we wana to be purist, we can check by Auth claims that user exists and have the right permision.

            return await Task.FromResult(_productRepository.Products);
        }


        /// <summary>
        /// Get All products
        /// </summary>
        /// <returns></returns>
        [HttpGet("{id}")]
        [Authorize(Roles = nameof(VPRoles.Admin) + "," + nameof(VPRoles.User))]
        [SwaggerResponse(StatusCodes.Status200OK, typeof(Product))]
        [SwaggerResponse(StatusCodes.Status500InternalServerError, typeof(HttpError))]
        public async Task<IActionResult> Get(long id)
        {

            //At this point, just the  Admin role have had access to this method.

            if (id <= 0)
                return await Task.FromResult(StatusCode(StatusCodes.Status400BadRequest));

            //Checking if Product  exists
            //Even if not exists products the DBSet never will be null... For that reason i'm not checking if is null.

            Product prod = _productRepository.Products.FirstOrDefault(p => p.Id == id);
            if (prod == null)
                return await Task.FromResult(StatusCode(StatusCodes.Status404NotFound));

            //Returning the Product
            return Ok(prod);
        }

        // POST api/products

        /// <summary>
        /// Create a Product
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = nameof(VPRoles.Admin))]
        [SwaggerResponse(StatusCodes.Status201Created)]
        [SwaggerResponse(StatusCodes.Status500InternalServerError, typeof(HttpError))]
        public async Task<IActionResult> Post([FromBody]Product product)
        {
            //By the fact I'm generating the Auth token with a private key, I'm assuming the user have access
            //If we wana to be purist, we can check by Auth claims that user exists and have the right permision.
            //To this method just enter the User having in its Auth Claim the "Admin" Role.

            //At this point, just the  Admin role have had access to this method, so, the validations are inherents
            //to Product to Create. See "ProductValidator.cs"

            //Setting current date.
            product.DateCreated = DateTime.Now;
            //I'm not checking if Product exists by Name, but in a real application probably should be a potential validation...
            long result = await _productRepository.AddProduct(product);

            int statusResult = result > 0 ? StatusCodes.Status201Created : StatusCodes.Status500InternalServerError;
            return await Task.FromResult(StatusCode(statusResult));

        }

        // PUT api/products

        /// <summary>
        /// Update a Product
        /// </summary>
        /// <returns></returns>
        [HttpPut("{id}")]
        [Authorize(Roles = nameof(VPRoles.Admin))]
        [SwaggerResponse(StatusCodes.Status204NoContent)]
        [SwaggerResponse(StatusCodes.Status500InternalServerError, typeof(HttpError))]
        public async Task<IActionResult> Put(int id, [FromBody]Product productToUpdate)
        {
            //At this point, just the  Admin role have had access to this method, so, the validations are inherents
            //to Product to Update. See "ProductValidator.cs"

            if (id <= 0)
                return await Task.FromResult(StatusCode(StatusCodes.Status400BadRequest));

            //Checking if Product  exists
            //Even if not exists products the DBSet never will be null... For that reason i'm not checking if is null.

            Product prod = _productRepository.Products.FirstOrDefault(p => p.Id == id);
            if (prod == null)
                return await Task.FromResult(StatusCode(StatusCodes.Status404NotFound));

            prod.Available = productToUpdate.Available;
            prod.Name = productToUpdate.Name.Trim(); //Had passed the validation for requirement of the Name not be empty 
            prod.Price = productToUpdate.Price;
            prod.Description = string.IsNullOrWhiteSpace(productToUpdate.Description) ? string.Empty : productToUpdate.Description.Trim();
            int result = _productRepository.UpdateProduct(prod);
            int statusResult = result > 0 ? StatusCodes.Status204NoContent : StatusCodes.Status500InternalServerError;
            return await Task.FromResult(StatusCode(statusResult));
        }


        // PUT api/products

        /// <summary>
        /// Delete a Product
        /// </summary>
        /// <returns></returns>
        [HttpDelete("{id}")]
        [Authorize(Roles = nameof(VPRoles.Admin))]
        [SwaggerResponse(StatusCodes.Status204NoContent)]
        [SwaggerResponse(StatusCodes.Status500InternalServerError, typeof(HttpError))]
        public async Task<IActionResult> Delete(long id)
        {

            //At this point, just the  Admin role have had access to this method, so, the validations are inherents
            //to Product to Delete. 

            if (id <= 0)
                return await Task.FromResult(StatusCode(StatusCodes.Status400BadRequest));

            //Checking if Product  exists
            //Even if not exists products the DBSet never will be null... For that reason i'm not checking if is null.

            Product prod = _productRepository.Products.FirstOrDefault(p => p.Id == id);
            if (prod == null)
                return await Task.FromResult(StatusCode(StatusCodes.Status404NotFound));

           
            int result = _productRepository.DeleteProduct(prod);
            int statusResult = result > 0 ? StatusCodes.Status204NoContent : StatusCodes.Status500InternalServerError;
            return await Task.FromResult(StatusCode(statusResult));

        }
    }

   

}
