﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using VP.Api.Base;
using VP.Api.Core;
using VP.Api.Infrastructure.HttpErrors;
using VP.Api.Models;

namespace VP.Api.Controllers
{
    /// <summary>
    /// For the Auth token management operations
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : VPControllerBase
    {
        private IConfiguration _config;

        private readonly ILogger<TokenController> _logger;

        private readonly UserManager<IdentityUser> _userManager;

        private readonly RoleManager<IdentityRole> _roleManager;


        public TokenController(IConfiguration config, ILogger<TokenController> log,
            UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _config = config;
            _logger = log;
            _userManager = userManager;
            _roleManager = roleManager;
        }


        // POST api/token

        /// <summary>
        /// EndPoint to Auth Users through JWT
        /// </summary>
        /// <param name="authRequest"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [SwaggerResponse(StatusCodes.Status500InternalServerError, typeof(HttpError))]
        public async Task<IActionResult> Post([FromForm]AuthRequest authRequest)
        {
            IActionResult response = Unauthorized();

            //If we are here, the request passed the Request object validation.

            //Before all, we check if User exists by email, and after If Pass is correct, I'll dont check another 
            //stuff but could be in a real life, like if user is blocked, etc... For the User Model I used 
            //"Asp.Net Identity Core", so I created the 2 Users with 2 Roles : "Admin & User", based in this i generate the token.

            IdentityUser user = await ValidateUser(authRequest);
            if (user == null)
                return response;

            //I'm assuming by the PoC that if the User after checked that exists, if not in "Admin" role is in "User" role
            string userRole = await _userManager.IsInRoleAsync(user, nameof(VPRoles.Admin)) ? nameof(VPRoles.Admin) : nameof(VPRoles.User);

            
            //Building Auth Token
            string tokenString = await BuildToken(GenerateClaimsForAuth(authRequest, userRole));

            response = Ok(new AuthResponse { Role = userRole, Token = tokenString });

            return response;

        }


        /// <summary>
        /// Validate the user that try to generate Token exists. Basically shoul be "admin@admin.com" or "user@user.com"
        /// and the pass should be correct, if not, return null for the unauthorized ;
        /// </summary>
        /// <param name="authRequest"></param>
        /// <returns></returns>
        private async Task<IdentityUser> ValidateUser(AuthRequest authRequest)
        {

            IdentityUser result = null;
            if (authRequest != null && !string.IsNullOrWhiteSpace(authRequest.Email)
                && !string.IsNullOrWhiteSpace(authRequest.Pass))
            {
                result = await _userManager.FindByEmailAsync(authRequest.Email);

                if (result != null)
                {
                    bool valid = await _userManager.CheckPasswordAsync(result, authRequest.Pass);
                    if (!valid)
                        return null;

                }
            }

            return await Task.FromResult(result);

        }

        /// <summary>
        /// For the generation of the Auth claims
        /// </summary>
        /// <param name="authRequest"></param>
        /// <param name="userRole"></param>
        /// <returns></returns>
        private List<Claim> GenerateClaimsForAuth(AuthRequest authRequest, string userRole) {

            List<Claim> claimsToBuild = new List<Claim>();
            claimsToBuild.AddRange(authRequest.ToClaims());

            //Adding the role of the user   
            claimsToBuild.Add(new Claim(ClaimTypes.Role, userRole, ClaimValueTypes.String));


            return claimsToBuild;
        }


        /// <summary>
        /// Build the Auth token by Bearer JWT
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        private async Task<string> BuildToken(IEnumerable<Claim> claims)
        {
            //await SeedData.Seeding(_userManager, _roleManager); //for seeding Data
            SymmetricSecurityKey key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            SigningCredentials creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            JwtSecurityToken token = new JwtSecurityToken(_config["Jwt:Issuer"],
              _config["Jwt:Issuer"],
              claims,
              expires: DateTime.Now.AddMinutes(30),
              signingCredentials: creds);

            return await Task.FromResult(new JwtSecurityTokenHandler().WriteToken(token));
        }




    }
}
