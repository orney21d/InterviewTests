﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP.Api.Infrastructure.HttpErrors
{
    /// <summary>
    /// Contract to implement Factory Pattern  for Error creation
    /// </summary>
    public interface IHttpErrorFactory
    {
        HttpError CreateFrom(Exception exception);
    }
}
