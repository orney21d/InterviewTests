﻿using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace VP.Api.Infrastructure.HttpErrors
{
    public class DefaultHttpErrorFactory : IHttpErrorFactory
    {
        /// <summary>
        /// Hosting environment
        /// </summary>
        private readonly IHostingEnvironment env;

        /// <summary>
        /// KeyPair collection by type and delegate
        /// </summary>
        private readonly IDictionary<Type, Func<Exception, HttpError>> factory;

        public DefaultHttpErrorFactory(IHostingEnvironment env)
        {
            this.env = env;

            //Initializing a factory
            factory = new Dictionary<Type, Func<Exception, HttpError>>
            {
                { typeof(Exception), InternalServerError }
            };
        }

        public HttpError CreateFrom(Exception exception)
        {
            if (factory.TryGetValue(exception.GetType(), out Func<Exception, HttpError> func))
            {
                return func(exception);
            }

            return factory[typeof(Exception)](exception);
        }

        private HttpError InternalServerError(Exception exception)
        {
            return HttpError.Create(
                env,
                status: HttpStatusCode.InternalServerError,
                code: string.Empty,
                userMessage: new[] { "Internal Server Error" },
                developerMessage: $"{exception.Message}\r\n{exception.StackTrace}");
        }
    }
}
