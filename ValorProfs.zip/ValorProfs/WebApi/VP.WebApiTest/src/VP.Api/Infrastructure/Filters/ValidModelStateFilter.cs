﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using VP.Api.Infrastructure.HttpErrors;

namespace VP.Api.Infrastructure.Filters
{
    /// <summary>
    /// Filter to intercept the invalid Models. It execute just before ActionMethod execution
    /// </summary>
    internal class ValidModelStateFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (context.ModelState.IsValid)
            {
                return;
            }

            //Getting All Validation Errors
            string[] validationErrors = context.ModelState
                .Keys
                .SelectMany(k => context.ModelState[k].Errors)
                .Select(e => e.ErrorMessage)
                .ToArray();



            var error = HttpError.CreateHttpValidationError(
                status: HttpStatusCode.BadRequest,
                userMessage: new[] { "There are validation errors" },
                validationErrors: validationErrors);

            context.Result = new BadRequestObjectResult(error);
        }
    }
}
