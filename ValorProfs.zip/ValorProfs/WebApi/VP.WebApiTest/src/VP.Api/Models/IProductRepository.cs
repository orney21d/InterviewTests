﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP.Api.Models
{
    public interface IProductRepository
    {
        IEnumerable<Product> Products { get; }

        Task<long> AddProduct(Product product);

        int DeleteProduct(Product productToDelete);

        int UpdateProduct(Product product);
    }
}
