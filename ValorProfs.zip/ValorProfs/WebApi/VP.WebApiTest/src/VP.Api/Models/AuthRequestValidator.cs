﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP.Api.Models
{
    public class AuthRequestValidator : AbstractValidator<AuthRequest>
    {

        public AuthRequestValidator()
        {

            RuleFor(x => x.Email).NotEmpty().WithMessage("The Email is required."); //This should be Localized but for PoC...


            RuleFor(x => x.Pass).NotEmpty().WithMessage("The Password is required.");//This should be Localized but for PoC...

            RuleFor(x => x.Email).EmailAddress().WithMessage("The Email value is not a valid Email Format."); //This should be Localized but for PoC...

        }
    }
}
