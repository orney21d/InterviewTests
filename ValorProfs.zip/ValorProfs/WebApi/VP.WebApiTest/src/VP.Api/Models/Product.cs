﻿using FluentValidation.Attributes;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VP.Api.Models
{
    /// <summary>
    /// Product entity
    /// </summary>
    [Validator(typeof(ProductValidator))]
    [DataContract]
    public class Product
    {
        
        [DataMember]
        public long Id { get; set; }

        [DataMember]
        public string Name { get; set; } = string.Empty;
        [DataMember]
        public bool Available { get; set; }
        [DataMember]
        public decimal Price { get; set; }


        [BindNever]
        [DataMember]
        public DateTime DateCreated { get; set; }

        [DataMember]
        public string Description { get; set; } = string.Empty;


    }
}
