﻿using FluentValidation.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace VP.Api.Models
{

    

    [Validator(typeof(AuthRequestValidator))]
    [DataContract]
    public class AuthRequest
    {
        [DataMember]
        public string Email { get; set; } = string.Empty;

        [DataMember]
        public string Pass { get; set; } = string.Empty;

        /// <summary>
        /// Get Claims from Entity
        /// </summary>
        /// <returns></returns>
        public List<Claim> ToClaims()
        {
            var claims = new List<Claim>
            {
                new Claim(nameof(Email), Email.ToString(), ClaimValueTypes.String)
                //new Claim(nameof(Pass), Pass.ToString(), ClaimValueTypes.String),
            };
            return claims;
        }

        /// <summary>
        /// Return entity from Claims
        /// </summary>
        /// <param name="claimList"></param>
        /// <returns></returns>
        public static AuthRequest FromClaims(IEnumerable<Claim> claimList)
        {
            var request = new AuthRequest();
            request.Email = claimList.FirstOrDefault(o => o.Type == nameof(Email))?.Value;
            request.Pass = claimList.FirstOrDefault(o => o.Type == nameof(Pass))?.Value;

            return request;
        }
    }
}
