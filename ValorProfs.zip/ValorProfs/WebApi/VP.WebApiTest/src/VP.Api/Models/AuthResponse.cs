﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VP.Api.Models
{
    /// <summary>
    /// Response for Success Authentication
    /// </summary>
    [DataContract]
    public class AuthResponse
    {
        /// <summary>
        /// Auth token to save it at client side
        /// </summary>
        [DataMember]
        public string Token { get; set; } = string.Empty;

        /// <summary>
        /// For easy client management ina friendly way. Although all permissions are checked at server side, this is just for the front View management.
        /// </summary>
        [DataMember]
        public string Role { get; set; }

    }
}
