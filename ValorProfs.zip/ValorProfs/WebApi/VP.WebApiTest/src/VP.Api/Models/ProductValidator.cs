﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP.Api.Models
{
    public class ProductValidator : AbstractValidator<Product>
    {

        public ProductValidator()
        {

            RuleFor(x => x.Name).NotEmpty().WithMessage("Product name required."); //This should be Localized but for PoC...


            RuleFor(x => x.Price).Cascade(CascadeMode.StopOnFirstFailure).NotEmpty().WithMessage("Price should be greather than 0.").GreaterThan(0).WithMessage("Price should be greather than 0.");//This should be Localized but for PoC...

            

        }
    }
}
