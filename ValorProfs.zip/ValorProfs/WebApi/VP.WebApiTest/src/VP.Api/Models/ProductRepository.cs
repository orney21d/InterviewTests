﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP.Api.Models
{
    public class ProductRepository : IProductRepository
    {
        private ProductDbContext _context;

        public ProductRepository(ProductDbContext context) => _context = context;
        
        public IEnumerable<Product> Products => _context.Products;


        /// <summary>
        /// Add specific product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public async Task<long> AddProduct(Product product)
        {
            await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();

            return await Task.FromResult(product.Id);
        }

        /// <summary>
        /// Remove specific product
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int DeleteProduct(Product productToDelete)
        {
            _context.Products.Remove(productToDelete);
            return _context.SaveChanges();

        }

        /// <summary>
        /// Update specific product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public int UpdateProduct(Product product)
        {
            _context.Products.Update(product);
            return _context.SaveChanges();
        }

       
    }
}
