﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP.Api.Core
{
    /// <summary>
    /// Used just one time to seed data
    /// </summary>
    public static class SeedData
    {
        public async static Task Seeding(UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            var existsRole = await roleManager.FindByNameAsync("Admin");
            if (existsRole == null || string.IsNullOrWhiteSpace(existsRole.Id))
            {

                await roleManager.CreateAsync(
                    new IdentityRole
                    {
                        Id = "b562e963-6e7e-4f41-8229-4390b1257hg5",
                        Name = "Admin",
                        NormalizedName = "ADMIN",

                    });

                await roleManager.CreateAsync(new IdentityRole
                {
                    Id = "f562e963-6e7e-4f43-8229-4390b1257hg5",
                    Name = "User",
                    NormalizedName = "USER",

                }
                     );

            }

            var existsUser = await userManager.FindByNameAsync("Admin");
            if (existsUser == null || string.IsNullOrWhiteSpace(existsUser.Id))
            {
                IdentityUser userAdmin = new IdentityUser
                {
                    EmailConfirmed = true,
                    UserName = "Admin",
                    Email = "admin@admin.com",
                    NormalizedEmail = "ADMIN@ADMIN.COM"
                };

                IdentityResult result = await userManager.CreateAsync(userAdmin, "admin123");
                if (result.Succeeded)
                {
                    IdentityRole approle = await roleManager.FindByNameAsync("Admin");
                    if (approle != null)
                    {
                        await userManager.AddToRoleAsync(userAdmin, approle.Name);
                    }
                }

                IdentityUser user = new IdentityUser
                {
                    EmailConfirmed = true,
                    UserName = "User",
                    Email = "user@user.com",
                    NormalizedEmail = "USER@USER.COM"
                };

                result = await userManager.CreateAsync(user, "user123");
                if (result.Succeeded)
                {
                    IdentityRole approle = await roleManager.FindByNameAsync("User");
                    if (approle != null)
                    {
                        await userManager.AddToRoleAsync(user, approle.Name);
                    }
                }
            }

        }
    }
}
