﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP.Api.Core
{
    /// <summary>
    /// ValorProfs DbContext to Manage Users /Roles By "Asp.Net Identity Core"
    /// </summary>
    public class VPUserDbContext: IdentityDbContext<IdentityUser, IdentityRole, string>
    {
        public VPUserDbContext(DbContextOptions<VPUserDbContext> options) : base(options)
        {

        }


    }
}
