﻿using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Swashbuckle.AspNetCore.Swagger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using VP.Api.Core;
using VP.Api.Infrastructure.Filters;
using VP.Api.Models;

namespace VP.Api
{
    /// <summary>
    /// Configurations for the WebApi... Separating responsibilities.
    /// </summary>
    public class ConfigurationApi
    {

        //#region Properties
        //public IConfiguration Configuration { get; }

        //public IHostingEnvironment Env { get; }
        //#endregion

        //public ConfigurationApi(IConfiguration configuration, IHostingEnvironment env)
        //{
        //    Configuration = configuration;
        //    Env = env;
        //}

        public static IServiceCollection ConfigureServices(IServiceCollection services, IConfiguration Configuration, IHostingEnvironment env)
        {

            services.AddMvcCore(config => config.Filters.Add(typeof(ValidModelStateFilter))) //Adding Filter to apply to all ActionMethod
                    .SetCompatibilityVersion(CompatibilityVersion.Version_2_1)  
                    .AddAuthorization()
                    .AddJsonFormatters()
                    .AddApiExplorer()
                    .AddFluentValidation(fv => fv.RegisterValidatorsFromAssembly(typeof(ConfigurationApi).Assembly)); //Registering all validation from current assembly
                                                                                                                      //.Services;


            #region Swagger

            // Register the Swagger generator, defining 1 or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "ValorProfs WebApi Test", Version = "v1" });
            });

            #endregion


            //Obteniendo el ConnectionString
            string conString = Configuration["ConnectionStrings:DefaultConnection"];

            //if (conString.Contains("%CONTENTROOTPATH%"))
            //{
            //    conString = conString.Replace("%CONTENTROOTPATH%", env.ContentRootPath);
            //}




            #region AspNet Identity Core
            //Get AssemblyName to set the current assembly as Migration's assembly 
            string migrationAssembly = typeof(ConfigurationApi).GetTypeInfo().Assembly.GetName().Name;

            //Registering DBContext to Manage Users & Roles with "Asp.Net Identity Core"
            services.AddDbContext<VPUserDbContext>(options =>
                    options.UseSqlServer(conString, sqlServerOptions =>
                    sqlServerOptions.MigrationsAssembly(migrationAssembly)
                    )
                );

            services.AddIdentity<IdentityUser, IdentityRole>(idOptp=>
            {
                idOptp.Password.RequireNonAlphanumeric = false;
                idOptp.Password.RequireUppercase = false;
            }
            )
                .AddEntityFrameworkStores<VPUserDbContext>();

            #endregion

            #region Products DBContext Config

            services.AddTransient<IProductRepository, ProductRepository>(); //Registering Product Repository
            services.AddDbContext<ProductDbContext>(options =>
                options.UseSqlServer(conString));

            #endregion

            return services;
        }

        public static IApplicationBuilder Configure(
            IApplicationBuilder app,
            Func<IApplicationBuilder, IApplicationBuilder> configureHost
            )
        {



            return configureHost(app)
                .UseSwagger()   // Enable middleware to serve generated Swagger as a JSON endpoint.
                .UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "ValorProfs WebApi Test"); //Enable middleware to serve swagger - ui(HTML, JS, CSS, etc.),  specifying the Swagger JSON endpoint.
                    c.RoutePrefix = string.Empty; //To serve the Swagger UI at the app's root (http://localhost:<port>/
                })
            .UseMvcWithDefaultRoute();
        }
    }
}
